RTA SENSORY ATLAS — ARHIVĂ PORTABILĂ DE CONTINUITATE

Snapshot GitHub SHA: 6490309a85c8c0dadaa934b886fcf33d5fcba68f
Sursă canonică: https://github.com/andreiclim77-cell/rta
Versiunea publicată: https://ghid-rta.ro/rta-lab/atlas/
Arhiva permanentă ÎN LAB: rta-lab/continuity/RTA_CONTINUITATE_CURENTA.zip

Într-un chat nou scrie: „Du-te în Lab și fă-ți update”.
Citește ÎN ORDINE:
1. rta-lab/CONTINUITY_START_HERE.md
2. rta-lab/RTA_CURRENT_HANDOFF.md
3. rta-lab/RTA_CONTINUITY_MASTER.md
4. rta-lab/RTA_ATLAS_DESIGN_BLUEPRINT.md
5. rta-lab/RTA_OPERATING_PROTOCOL.md
6. rta-lab/RTA_COIL_STYLE_CURRENT_20261108.md — CONTACT/SPACED/NECONFIRMAT
7. rta-lab/RTA_K1_FOUR_BUILDS_20261111.md — 01A K1 28 GA și 01B K1 29 GA, ambele Ø2,5 mm; 02+ NUMAI NiFe/SS Clapton, fără K1/K1 Clapton

La „Salvează” actualizează aplicația și arhiva ÎN LAB (Biblioteca este doar o oglindă opțională).
La „Dă-mi arhiva de continuitate la zi” generează snapshotul actual și oferă linkul.

Acest pachet conține documentele integrale și extrasele esențiale de cod
și QA pentru context fără istoric de conversație. Catalogul mare, media,
build-ul executabil și istoricul git complet RĂMÂN în repository.
Verifică SHA-ul curent pe main, workflow-urile și Pages; snapshotul nu poate
demonstra un deploy viitor sau o preferință încă neconfirmată.
Dacă GitHub nu este conectat, poți folosi documentele din acest ZIP
ca plan de reluare, apoi reconectezi repo-ul pentru editare.
