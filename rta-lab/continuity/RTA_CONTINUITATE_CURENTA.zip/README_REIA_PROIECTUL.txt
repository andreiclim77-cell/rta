RTA SENSORY ATLAS — ARHIVĂ PORTABILĂ DE CONTINUITATE

Snapshot GitHub SHA: 561ed0bbfa7f1a3651b729be3b0e81c458a4a3d6
Sursă canonică: https://github.com/andreiclim77-cell/rta
Versiunea publicată: https://ghid-rta.ro/rta-lab/atlas/
Arhiva permanentă ÎN LAB: rta-lab/continuity/RTA_CONTINUITATE_CURENTA.zip

Într-un chat nou scrie: „Du-te în Lab și fă-ți update”.
Citește ÎN ORDINE:
1. rta-lab/CONTINUITY_START_HERE.md
2. rta-lab/RTA_CURRENT_HANDOFF.md
3. rta-lab/RTA_CONTINUITY_MASTER.md
4. rta-lab/RTA_ATLAS_DESIGN_BLUEPRINT.md
5. rta-lab/RTA_OPERATING_PROTOCOL.md
6. rta-lab/RTA_COIL_STYLE_CURRENT_20261108.md — CONTACT/SPACED/NECONFIRMAT
7. rta-lab/RTA_K1_FOUR_BUILDS_20261111.md — 01A K1 28 GA și 01B K1 29 GA, ambele Ø2,5 mm; 02+ NUMAI NiFe/SS Clapton, fără K1/K1 Clapton

8. rta-lab/RTA_TC_SPACED_STANDARD_20261127.md — NiFe30/7 SPACED și NiFe52/6 SPACED (6 NiFe30 doar istoric)
9. rta-lab/RTA_UPDATE_20261121.md și RTA_INVENTAR_20261121.json — colecția, preferințele și probele curente din 21.11.2026

La „Salvează” actualizează aplicația și arhiva ÎN LAB (Biblioteca este doar o oglindă opțională).
La „Dă-mi arhiva de continuitate la zi” generează snapshotul actual și oferă linkul.

Acest pachet conține documentele integrale și extrasele esențiale de cod
și QA pentru context fără istoric de conversație. Catalogul mare, media,
build-ul executabil și istoricul git complet RĂMÂN în repository.
Verifică SHA-ul curent pe main, workflow-urile și Pages; snapshotul nu poate
demonstra un deploy viitor sau o preferință încă neconfirmată.
Dacă GitHub nu este conectat, poți folosi documentele din acest ZIP
ca plan de reluare, apoi reconectezi repo-ul pentru editare.
