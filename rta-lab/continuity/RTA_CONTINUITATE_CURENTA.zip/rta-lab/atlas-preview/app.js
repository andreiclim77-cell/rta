/* RTA Sensory Atlas · standalone Home + Liquid Cinema prototype.
   Verified commercial 700 catalog / 13 active classic RTAs + 1 Boro / 16 historical classic models.
   Concept preview: no edits to V10 engine, no invented reviews, percentages or product photos. */
(function(){
"use strict";
const catalog=window.RTA_LIQUIDS||[];
const sourceAtoms=window.RTA_CORE?.atoms||[];
const soldIds=Object.freeze(['415','kv3']);
const atoms=sourceAtoms.filter(a=>a.id!=='asylum'&&!soldIds.includes(a.id));
// Keep the 16-platform technical archive intact. GAIA is a separate Boro bridge,
// not a classic RTA with an invented Sensory DNA or a made-up personal A/B.
const boro=Object.freeze([{id:'taifun-gaia-boro',label:'Taifun GAIA RBA',maker:'SmokerStore / Taifun',type:'Boro RBA',units:1,
 evidence:'Achiziție confirmată 07.11.2026; build, airflow și performanță încă necomunicate.'}]);
window.RTA_ATLAS_COLLECTION=Object.freeze({
 activeAtoms:atoms,activeRtaPlatforms:atoms.length,activeRtaUnits:39,
 ownedBoro:boro,activeBoroPlatforms:boro.length,activeBoroUnits:1,
 activePlatforms:atoms.length+boro.length,activeUnits:40,
 sold:Object.freeze([{id:'415',label:'415 RTA MTL Cool',unitsSold:1,decided:'2026-11-07'},
  {id:'kv3',label:'Kayfun Mini V3',unitsSold:1,decided:'2026-11-07'}]),
 retired:Object.freeze([{id:'asylum',label:'Asylum V3',unitsRecorded:2,
  disposition:'de donat — predarea nu este confirmată',
  evaluation:'Aromă bună, la nivel Revorie; doar aromă, fără TH și ofensivă satisfăcătoare.',
  decided:'2026-10-19'}]),
 isActive:id=>atoms.some(a=>a.id===id)
});
const core=window.RTA_SENSORY_CORE;
const moodEngine=window.RTA_MOOD_MATCH;
if(!core||!moodEngine||catalog.length!==700||window.RTA_ATLAS_CATALOG?.edition!=='20261015-700-v1'||(sourceAtoms.length!==16||atoms.length!==13))return;
const moodList=moodEngine.moods, momentList=moodEngine.moments;
const defaultLiquid=(()=>{
 const exact=catalog.findIndex(x=>x.brand==="La Tabaccheria"&&x.name==="Balkan Mixture");
 if(exact>=0)return exact;
 const similar=catalog.findIndex(x=>x.class==="NET complex"&&/Balkan/i.test(x.name));
 return similar>=0?similar:catalog.findIndex(x=>x.class==="NET complex");
})();
const state={route:"home",liquidIndex:Math.max(0,defaultLiquid),mood:"magic",moment:"evening",expandedId:null,search:"",activeSuggestion:0,fromDemo:true,freeProfile:null,objective:null};
const navigationTrail=[];
const routePositions=new Map();
const esc=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");
const norm=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
const liquidName=l=>window.RTA_ATLAS_SEARCH?.label(l)||[l?.brand,l?.name].filter(Boolean).join(" · ");
const moodById=id=>moodList.find(m=>m.id===id);
const momentById=id=>momentList.find(m=>m.id===id);
const atomById=id=>atoms.find(a=>a.id===id);
const tech=atomId=>core.platforms[atomId];
const round=n=>Math.round(n*100)/100;
const element=id=>typeof document!=="undefined"?document.getElementById(id):null;
function liquidSearch(q,limit=10){
 const needle=norm(q).trim();
 if(needle.length<2)return [];
 if(window.RTA_ATLAS_SEARCH)return window.RTA_ATLAS_SEARCH.find(q).rows.slice(0,limit);
 const hits=[];
 for(let i=0;i<catalog.length&&hits.length<limit;i++){
  const l=catalog[i];
  const hay=norm([l.brand,l.name,l.profile,l.class,l.line,(l.tags||[]).join(" ")].join(" "));
  if(hay.includes(needle))hits.push({index:i,liquid:l});
 }
 return hits;
}
function currentLiquid(){return state.freeProfile||catalog[state.liquidIndex]||catalog[0];}
function effectiveGoal(moodId=state.mood){return state.objective||moodById(moodId)?.goal||"complete";}
function buildString(result){
 const cfg=result.config,w=core.wires[cfg.wire],air=tech(cfg.atom)?.air.find(a=>a.id===cfg.air);
 return w.name+" · "+core.coilLabel(cfg)+" · "+(air?air.label:"airflow configurabil");
}
function buildEnergy(result){
 const c=result.config,w=core.wires[c.wire];
 return core.modeFor(c)==="tc"?"TC "+c.temp+"°C · limită "+c.power+" W":"WATT "+c.power+" W"+(c.wire==="nife30"&&c.chipset?" · "+core.nife30Watt.chipsets[c.chipset]:"");
}
function setupSummary(result){
 const c=result.config;
 return "Ø"+String(c.coilMm).replace(".",",")+" mm · "+buildEnergy(result);
}
function compactBuild(result){
 const c=result.config,w=core.wires[c.wire];
 const name=w.name.replace("Dicodes RESISTHERM ","Dicodes ").replace("Kanthal A1 ","K1 ");
 return name+" · "+core.coilLabel(c)+" · Ø"+String(c.coilMm).replace(".",",")+" · "+buildEnergy(result);
}
function labelScore(v){
 if(v>=4.65)return "foarte pronunțat";
 if(v>=4.2)return "pronunțat";
 if(v>=3.6)return "echilibrat";
 return "moderat";
}
const signalNames={
 spectrum:"spectru",separation:"separare",simultaneity:"simultaneitate",
 palate:"palat",offense:"ofensivă",th:"TH",harmony:"armonie",
 focus:"focus",texture:"textură",tobaccoCore:"tutun"
};
function qualities(result){
 const r=result.signals;
 const main=["spectrum","simultaneity","palate","offense","th","harmony"];
 return main.map(key=>({key,value:r[key]})).sort((a,b)=>b.value-a.value).slice(0,3)
  .map(o=>signalNames[o.key]+" "+labelScore(o.value));
}
function vapeDescription(result,liquid){
 const s=result.signals;
 const first=s.simultaneity>=4.55?"note aromatice simultane":s.focus>=4.55?"aromă focalizată":"arhitectură aromatică echilibrată";
 const pal=s.palate>=4.65?"palat bogat":s.palate>=4.1?"palat prezent":"senzație pe palat mai rezervată";
 const force=s.offense>=4.6?"ofensivă puternică":s.offense<3.55?"atac mai blând":"ofensivă controlată";
 const th=s.th>=4.55?"TH pronunțat":s.th<3.6?"TH discret":"TH echilibrat";
 const mood=moodById(state.mood);
 return first+", "+pal+", "+force+" și "+th+". Interpretare tehnică orientativă pentru "+liquid.name+" / "+(mood?.name||"context")+".";
}
function evidenceFor(result,liquid){
 // Distinguish a report tied to this named liquid from an unspecified-liquid
 // user report (e.g. KLP NiFe30) and a report on a DIFFERENT named liquid.
 if(liquid?.isFreeProfile)return {label:liquid.sourceReview?"Extrapolare pe profil de review · nu testul acestui build":"Estimare pentru profilul declarat · fără A/B pe un lichid comercial",kind:"model"};
 const partial=result.partialEvidence||[];
 const exact=partial.some(r=>r.liquidName&&norm(r.liquidName)===norm(liquid.name));
 const unknownLiquid=partial.some(r=>!r.liquidName);
 if(result.anchors?.length)return {label:"Build observat · potrivire pe lichid modelată",kind:"user"};
 if(exact)return {label:"Observație personală parțială pe lichidul selectat",kind:"partial"};
 if(unknownLiquid)return {label:"Observație personală cu lichid neprecizat · aplicarea aici este extrapolată",kind:"partial-context"};
 if(result.personalPreference?.tier===1)return {label:"Preferință personală declarată · rezultat contextual",kind:"user"};
 return {label:"Extrapolare tehnică · nu A/B pe acest lichid",kind:"model"};
}
function rankFor(liquidIndex,moodId,momentId,override={}){
 const liquid=override.liquid||catalog[liquidIndex],mood=moodById(moodId),goal=override.objective||mood?.goal;
 if(!liquid||!mood||!momentById(momentId))return null;
 const adapted=override.liquid?.isFreeProfile||override.objective;
 const base=adapted?{ranked:window.RTA_ATLAS_CONTEXT.rank(liquid,moodId,momentId,goal)}:moodEngine.recommend(moodId,momentId,liquidIndex);
 if(!base||!Array.isArray(base.ranked))return null;
 // Use actual sorted contextual ranking, NOT Mood Match's exploratory third slot.

 const selected=base.ranked.filter(a=>window.RTA_ATLAS_COLLECTION.isActive(a.id)).slice(0,3).map((a,i)=>{
  // One distinct wire material per proposal; the retired Dicodes six-wrap
  // entry is never substituted with a second NiFe duplicate. Fill remaining
  // slots with the best contextual non-NiFe material.
  const candidates=core.rankBuilds(a.id,liquid,goal);
  const picks=[],used=new Set();
  for(const item of candidates){
   if(used.has(item.config.wire))continue;
   picks.push(item);used.add(item.config.wire);
   if(picks.length===3)break;
  }
  if(!picks.some(x=>!x.config.wire.startsWith("nife"))){
   const alternative=candidates.find(x=>!x.config.wire.startsWith("nife")&&!used.has(x.config.wire));
   if(alternative)picks.splice(Math.max(0,picks.length-1),1,alternative);
  }
  return {id:a.id,atom:atomById(a.id),score:a.score,position:i+1,builds:picks};
 });
 return {liquid,mood,moment:momentById(momentId),objective:goal,items:selected};
}
function renderAbstractAtom(atom,rank){
 const originalRecord=window.RTA_ATLAS_PHOTOS?.[atom.id];
 const local=window.RTA_ATLAS_LOCAL_PHOTOS?.[atom.id];
 const record=originalRecord&&{...originalRecord,src:local?.src||originalRecord.src,credit:originalRecord.credit+(local?.provenance==="exact-source-copy"?" · copie locală":"")};
 if(!record)return '<div class="atlas-missing-photo">Fotografie verificată încă indisponibilă pentru '+esc(atom.short)+'</div>';
 return '<figure class="atlas-product-photo" data-photo-model="'+esc(atom.id)+'">'+
  '<img src="'+esc(record.src)+'" loading="lazy" decoding="async" alt="'+esc(atom.short)+' — fotografie de produs" />'+
  '<figcaption><a href="'+esc(record.ref)+'" target="_blank" rel="noopener noreferrer" title="Fotografie reală: '+esc(record.credit)+'">FOTO: '+esc(record.credit)+' ↗</a></figcaption>'+
  '</figure>';
}
function renderCoil(config){
 const a=tech(config.atom)?.air.find(x=>x.id===config.air);
 const holes=Array.isArray(a?.holes)?a.holes.length:((a?.pattern==="multipoint")?3:1);
 const number=Math.min(7,Math.max(3,config.wraps));
 const pitch=config.spacing==="spaced"?24:20;
 const coilWidth=number*pitch,offset=120-coilWidth/2;
 const coilCy=config.position==="low"?47:config.position==="high"?31:39,coilRy=16*(config.coilMm/2.5);
 const rings=Array.from({length:number},(_,i)=>'<ellipse cx="'+(offset+pitch/2+i*pitch)+'" cy="'+coilCy+'" rx="'+(config.spacing==="spaced"?9:11)+'" ry="'+coilRy+'" fill="none" stroke="#d6b990" stroke-width="3.5"/>').join("");
 const holeDots=Array.from({length:Math.min(5,holes)},(_,i)=>{
  const cx=120+(i-(Math.min(5,holes)-1)/2)*30;
  return '<circle cx="'+cx+'" cy="79" r="4" fill="#80c9bc"/>'+
   '<path d="M'+cx+' 75 L'+cx+' 54" fill="none" stroke="#90d7cb" stroke-width="2" stroke-linecap="round" class="air-beams"/>';
 }).join("");
 const ct=core.modeFor(config)==="tc";
 return '<svg viewBox="0 0 240 100" role="img" aria-label="Schemă animată: '+esc(core.coilLabel(config))+' și '+holes+(holes===1?' canal':' canale')+' de aer, nu simulare fizică">'+
 '<path d="M15 43H48 M192 43H224" stroke="#819c9d" stroke-width="3"/>'+
 rings+holeDots+'<path d="M45 85H195" stroke="#5d8f84" opacity=".4"/>'+
 '<text x="6" y="15" font-size="9" letter-spacing="1.2" fill="'+(ct?"#d4c7a5":"#90c5b9")+'">'+(ct?"TC CONTROL":"WATT DRIVE")+'</text></svg>';
}
function renderBuild(result,rank,liquid){
 const cfg=result.config,w=core.wires[cfg.wire];
 const evidence=evidenceFor(result,liquid);
 const line=vapeDescription(result,liquid);
 return '<article class="build-card'+(rank===1?' build-lead':'')+'">'+
  '<span class="build-badge">'+(rank===1?'01 · CEA MAI BUNĂ POTRIVIRE CALCULATĂ':'0'+rank+' · ALTERNATIVĂ CONTEXTUALĂ')+'</span>'+
  '<strong>'+esc(w.name)+' / '+esc(core.coilLabel(cfg))+'</strong>'+
  '<div class="build-visual">'+renderCoil(cfg)+'</div>'+
  '<div class="build-technical"><b>Insert:</b> '+esc(tech(cfg.atom).air.find(a=>a.id===cfg.air)?.label||"variabil")+'<br>'+
  '<b>Clopot:</b> '+esc(window.RTA_BELL_LIQUID_FIT.config(cfg.atom)?.bells?.find(b=>b.id===cfg.bell)?.name||"standard")+'<br>'+
  '<b>Regim:</b> '+esc(setupSummary(result))+'</div>'+
  '<p class="build-sensory">'+esc(line)+'</p><p class="build-trade"><b>Accent:</b> '+esc(result.advantages.slice(0,2).join(' · '))+'<br><b>Compromis:</b> '+esc(result.tradeoffs[0]||'Verifică practic echilibrul în contextul tău.')+'</p>'+
  '<div class="build-evidence">'+esc(evidence.label)+'</div><button type="button" class="module-link" data-wire-open="'+esc(encodeURIComponent(JSON.stringify(cfg)))+'">Deschide în Wire Lab ↗</button><button type="button" class="module-link" data-duel-pick="'+esc(encodeURIComponent(JSON.stringify(cfg)))+'">Adaugă la Duel ↗</button></article>';
}
function comparisonGraphic(entries,title){
 const axes=[['spectrum','Spectru'],['separation','Separare'],['simultaneity','Simultaneitate'],['palate','Palat'],['offense','Ofensivă'],['th','Throat hit'],['harmony','Armonie']];
 return '<figure class="sensory-comparison"><figcaption><h3>'+esc(title)+'</h3><p>Același lichid și obiectiv. Lungimea barelor arată indicatori ai modelului; nu măsurători sau procente de plăcere.</p></figcaption><div class="comparison-legend">'+entries.map((e,i)=>'<span class="series-'+i+'"><i></i>'+esc(/^[ABC] · /.test(e.label)?e.label:String.fromCharCode(65+i)+' · '+e.label)+'</span>').join('')+'</div>'+axes.map(([key,label])=>'<div class="comparison-axis"><b>'+label+'</b><div>'+entries.map((e,i)=>'<div class="comparison-track series-'+i+'" data-signal="'+key+'" data-value="'+e.result.signals[key]+'" role="img" aria-label="'+esc(e.label+' · '+label+' · '+labelScore(e.result.signals[key]))+'"><span style="width:'+Math.max(0,Math.min(100,e.result.signals[key]*20))+'%"></span><small>'+String.fromCharCode(65+i)+' · '+esc(labelScore(e.result.signals[key]))+'</small></div>').join('')+'</div></div>').join('')+'</figure>';
}
function watchInternal(item){
 const alt=item.builds[1];
 if(!alt)return "Nu există deocamdată o a doua combinație compatibilă documentată.";
 return "Merită comparat și "+buildString(alt)+". Modelul sugerează alt echilibru; nu îl prezentăm drept A/B confirmat pe lichidul ales.";
}
function renderResult(item,liquid){
 const best=item.builds[0],evidence=evidenceFor(best,liquid);
 const selected=state.expandedId===item.id;
 const strengths=qualities(best).map(s=>'<span class="sensory-token">'+esc(s)+'</span>').join("");
 const count=item.builds.length;
 return '<article class="result-card" data-atom="'+esc(item.id)+'">'+
 '<div class="card-main">'+
 '<div class="atom-portrait">'+renderAbstractAtom(item.atom,item.position)+'<span>STUDIU VIZUAL · SCHEMATIC</span></div>'+
 '<div class="card-body"><span class="card-overline">0'+item.position+' / '+esc(item.position===1?"POTRIVIREA CONTEXTUALĂ PRINCIPALĂ":"O ALTĂ INTERPRETARE")+'</span>'+
 '<h3>'+esc(item.atom.short)+'</h3>'+
 '<p>'+esc(vapeDescription(best,liquid))+'</p>'+
 '<div class="best-config"><span>BEST BUILD</span> · '+esc(buildString(best))+'</div>'+
 '<div class="sensory-tokens">'+strengths+'</div></div>'+
 '<div class="card-side"><span class="card-rank">0'+item.position+'</span>'+
 '<button type="button" class="open-builds" data-expand="'+esc(item.id)+'" aria-expanded="'+String(selected)+'" aria-controls="detail-'+esc(item.id)+'">'+(selected?'Închide buildurile':'Vezi '+count+' builduri și diferențele')+' <span aria-hidden="true">'+(selected?'−':'+')+'</span></button></div></div>'+
 '<div class="card-detail" id="detail-'+esc(item.id)+'"'+(selected?'':' hidden')+'>'+
 '<p class="detail-intro"><strong>'+esc(evidence.label)+'.</strong> Configurațiile sunt ordonate pentru '+esc(liquid.name)+' în contextul ales; experiența ta directă primează unde există un test relevant.</p>'+
 '<div class="detail-grid">'+item.builds.map((b,i)=>renderBuild(b,i+1,liquid)).join("")+'</div>'+
 comparisonGraphic(item.builds.map(b=>({label:core.wires[b.config.wire].name+' / '+core.coilLabel(b.config),result:b})),'Cum diferă cele trei builduri')+
 '<div class="watchlist"><div class="watch-item"><b>01 / De urmărit — din experiența ta</b><p>'+esc(watchInternal(item))+'</p></div>'+
 '<div class="watch-item market"><b>02 / De urmărit — din piață</b><p>'+(window.RTA_ATLAS_MARKET?.watch(liquid)||'Semnalul extern pentru acest setup este încă în cercetare. Nu inventăm consensul din review-uri; sursele vor fi legate numai după verificare.')+'</p></div></div>'+
 '<p class="detail-foot">Graficele și schemele sunt ilustrații tehnice. Nu sunt măsurători ale temperaturii, debitului, gustului sau procente ale plăcerii.</p></div></article>';
}
function compose(liquidIndex,moodId,momentId,override={}){
 const ranked=rankFor(liquidIndex,moodId,momentId,override);
 if(!ranked)return null;
 return {
  ...ranked, countAtoms:atoms.length,countLiquids:catalog.length,
  distinctAtoms:new Set(ranked.items.map(i=>i.id)).size,
  distinctBuilds:ranked.items.reduce((n,i)=>n+i.builds.length,0),
  source:(override.liquid?.isFreeProfile||override.objective)?"RTA_SENSORY_CORE + adapter al formulei Mood Match":"RTA_SENSORY_CORE.rankBuilds + RTA_MOOD_MATCH.recommend.ranked"
 };
}
function drawScene(){
 const l=currentLiquid();
 if(!l)return;
 const tags=(l.tags||[]).slice(0,4);
 element("sceneCategory").textContent=l.class.toUpperCase();
 element("sceneLabel").textContent=/(complex)/i.test(l.class)?"Straturi. Profunzime. Simultaneitate.":"Un caracter. Un centru aromatic.";
 element("sceneTags").innerHTML=tags.length?tags.map(t=>'<span>'+esc(t.toUpperCase())+'</span>').join(""):
 '<span>'+(l.isFreeProfile?"PROFIL DECLARAT":"PROFIL DIN CATALOG")+'</span>';
 const dark=/(latakia|kentucky|dark|cigar)/i.test([l.profile,...(l.tags||[])].join(" "));
 document.querySelector(".live-scene")?.classList.toggle("scene-dark",dark);
}
function updateSceneMatch(result){
 const item=result?.items?.[0],build=item?.builds?.[0];
 const atom=element("sceneMatchAtom"),detail=element("sceneMatchBuild");
 if(!atom||!detail)return;
 atom.textContent=build?(item.atom?.short||item.id):"Context indisponibil";
 detail.textContent=build?compactBuild(build):"Alege alt context.";
 detail.title=build?buildString(build)+" · "+setupSummary(build):"";
}
function scrollToBest(){
 const target=element("resultCards")?.querySelector(".result-card")||element("resultsSection");
 target?.scrollIntoView({block:"start",behavior:window.matchMedia?.("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"});
}
function revealSelectedChips(){
 if(!window.matchMedia?.("(max-width:760px)").matches)return;
 for(const id of ["moodChips","momentChips"]){
  const rail=element(id),chip=rail?.querySelector(".chip.active");
  if(!rail||!chip)continue;
  const box=rail.getBoundingClientRect(),item=chip.getBoundingClientRect();
  if(!box.width||!item.width)continue;
  if(item.right>box.right-8)rail.scrollLeft+=item.right-box.right+12;
  else if(item.left<box.left+8)rail.scrollLeft-=box.left-item.left+12;
 }
}
function renderResults(){
 const box=element("resultCards");
 if(!box)return;
 const awaiting=state.fromDemo&&!state.freeProfile;
 element("pageLiquid").classList.toggle("is-awaiting-liquid",awaiting);
 element("matchButton").disabled=awaiting;
 element("liquidTitle").innerHTML=awaiting?'Alege lichidul.<br><em>Apoi configurația.</em>':'Lichidul tău.<br><em>9 configurații.</em>';
 if(awaiting){box.innerHTML='';element("resultsSummary").textContent='Alege întâi lichidul din catalog.';element("resultCounter").textContent='—';updateSceneMatch(null);return;}
 const result=compose(state.liquidIndex,state.mood,state.moment,{liquid:currentLiquid(),objective:state.objective});
 if(!result){
  box.innerHTML='<div class="empty-results">Nu avem suficiente date pentru acest context. Selectează alt lichid sau altă stare.</div>';
  updateSceneMatch(null);
  return;
 }
 if(state.expandedId===null&&result.items.length&&!window.matchMedia?.("(max-width:760px)").matches)state.expandedId=result.items[0].id;
 if(state.expandedId&&!result.items.some(x=>x.id===state.expandedId))
  state.expandedId=result.items[0]?.id||null;
 element("resultsSummary").textContent=liquidName(result.liquid)+" · "+result.mood.name+" · "+result.moment.name+" · "+(window.RTA_ATLAS_CONTEXT.goals.find(g=>g[0]===result.objective)?.[1]||result.objective)+
 " · ordonare contextuală din "+atoms.length+" platforme active.";
 element("resultCounter").textContent="TOP 3 · 3 × 3";
 box.innerHTML=result.items.map(x=>renderResult(x,result.liquid)).join("");
 if(element('liquidComparison'))element('liquidComparison').innerHTML=comparisonGraphic(result.items.map(x=>({label:x.atom.short,result:x.builds[0]})),'Cum diferă cele trei atomizoare');
 updateSceneMatch(result);
 if(state.route==='liquid'&&window.requestAnimationFrame)window.requestAnimationFrame(revealSelectedChips);
}
function renderMoodMoment(){
 element("moodChips").innerHTML=moodList.map(m=>
 '<button class="chip'+(state.mood===m.id?' active':'')+'" type="button" data-mood="'+esc(m.id)+'" aria-pressed="'+(state.mood===m.id)+'"><span class="chip-emoji">'+m.icon+'</span>'+esc(m.name)+'</button>').join("");
 element("momentChips").innerHTML=momentList.map(m=>
 '<button class="chip'+(state.moment===m.id?' active':'')+'" type="button" data-moment="'+esc(m.id)+'" aria-pressed="'+(state.moment===m.id)+'"><span class="chip-emoji">'+m.icon+'</span>'+esc(m.name)+'</button>').join("");
 revealSelectedChips();
}
function selectLiquid(index,manual=true){
 if(!Number.isInteger(index)||!catalog[index])return false;
 state.freeProfile=null;state.liquidIndex=index;state.fromDemo=!manual;state.expandedId=null;
 element("liquidSearch").value=manual?liquidName(catalog[index]):'';
 element("selectedLiquid").innerHTML=manual?'<span class="check" aria-hidden="true">✓</span><span><b>'+esc(liquidName(catalog[index]))+'</b> · ales de tine</span>':'<span>Caută și alege lichidul tău din cele '+catalog.length+'. Rezultatele apar după alegere.</span>';
 if(manual&&window.RTA_ATLAS_SEARCH)element("selectedLiquid").insertAdjacentHTML("beforeend",window.RTA_ATLAS_SEARCH.sourceNote(catalog[index]));
 element("liquidSuggestions").hidden=true;
 element("liquidSearch").setAttribute("aria-expanded","false");
 element("liquidSearch").removeAttribute("aria-activedescendant");
 drawScene();
 renderResults();
 return true;
}
function setObjective(id){
 if(id!==''&&id!==null&&!window.RTA_ATLAS_CONTEXT.goals.some(g=>g[0]===id))return false;
 state.objective=id||null;
 const mod=window.RTA_ATLAS_MODULES;if(mod){mod.state.objective=effectiveGoal();mod.state.goalLocked=!!state.objective;}
 if(element('liquidObjective'))element('liquidObjective').value=state.objective||'';
 if(element('resultCards'))renderResults();return true;
}
function setFreeProfile(input){
 const free=window.RTA_ATLAS_CONTEXT.profile(input);if(!free)return false;state.freeProfile=free;state.fromDemo=false;state.expandedId=null;
 if(element('liquidSearch')){element('liquidSearch').value='';element('selectedLiquid').innerHTML='<span class="check" aria-hidden="true">◎</span><span><b>'+esc(free.name)+'</b> · '+(free.sourceReview?'profil din review':'profil declarat')+' / '+esc(free.class)+'</span>';closeSuggestions();drawScene();renderResults();}
 return true;
}
function setContext(changes){
 if(changes.mood&&!moodById(changes.mood)||changes.moment&&!momentById(changes.moment))return false;
 if(changes.mood)state.mood=changes.mood;if(changes.moment)state.moment=changes.moment;
 state.expandedId=null;renderMoodMoment();renderResults();
 window.RTA_ATLAS_MODULES?.show(state.route);return true;
}
function renderSuggestions(){
 const input=element("liquidSearch"),box=element("liquidSuggestions");
 const rows=liquidSearch(input.value,10);
 box.hidden=!rows.length;
 input.setAttribute("aria-expanded",String(!!rows.length));
 state.activeSuggestion=0;
 input.setAttribute("aria-activedescendant",rows.length?"liquidOpt0":"");
 box.innerHTML=rows.map((x,i)=>
  '<button type="button" id="liquidOpt'+i+'" class="suggestion'+(i===0?' is-active':'')+'" role="option" aria-selected="'+(i===0)+'" data-liquid="'+x.index+'">'+
  '<strong>'+esc(liquidName(x.liquid))+'</strong><small>'+esc(x.liquid.class)+' · '+esc(x.liquid.profile||"")+'</small></button>').join("");
}
function closeSuggestions(){
 element("liquidSuggestions").hidden=true;
 element("liquidSearch").setAttribute("aria-expanded","false");
 element("liquidSearch").removeAttribute("aria-activedescendant");
}
function route(to,push=true){
 if(state.incomplete)return false;
 if(!["home","liquid",...(window.RTA_ATLAS_MODULES?.routes||[])].includes(to))return false;
 const from=state.route;if(from==='wire'&&to!=='wire'&&window.RTA_ATLAS_DUEL?.state.editing)window.RTA_ATLAS_DUEL.state.editing=null;if(from!==to)routePositions.set(from,window.scrollY||0);if(push&&from!==to)navigationTrail.push(from);
 state.route=to;
 const isHome=to==="home";
 element("pageHome").hidden=!isHome;
 element("pageLiquid").hidden=to!=="liquid";
 window.RTA_ATLAS_MODULES?.show(to);
 document.querySelectorAll("[data-route]").forEach(el=>{
  if(el.tagName==="BUTTON"&&(el.closest(".top-nav")||el.closest(".bottom-tabs"))){
   if(el.dataset.route===to)el.setAttribute("aria-current","page");
   else el.removeAttribute("aria-current");
  }
 });
 const back=element('atlasBack');if(back){back.hidden=isHome;back.title='Revino la instrumentul anterior; alegerile sunt păstrate';}
 if(push&&from!==to&&window.history?.pushState){
  window.history.pushState(null,"","#"+to);
 }
 window.scrollTo?.({top:push?0:routePositions.get(to)||0,behavior:"instant"});
 if(to==="liquid"&&push&&state.fromDemo&&!state.freeProfile)element("liquidSearch")?.focus({preventScroll:true});
 if(!isHome&&window.requestAnimationFrame)window.requestAnimationFrame(revealSelectedChips);
 return true;
}
function init(){
 if(!element("pageHome")||!element("pageLiquid"))return;
 renderMoodMoment();
 selectLiquid(state.liquidIndex,false);
 route(window.location?.hash==="#liquid"?"liquid":"home",false);
 document.addEventListener("click",ev=>{
  const target=ev.target.closest?.("[data-route],[data-liquid],[data-mood],[data-moment],[data-expand],[data-go-best],[data-compare-atoms]");
  if(!target)return;
  const d=target.dataset;
  if(d.route){ev.preventDefault();route(d.route);return;}
  if(d.goBest!=null){scrollToBest();return;}
  if(d.compareAtoms!=null){const graph=element('liquidComparison'),header=document.querySelector('.mast');if(graph)window.scrollTo({top:Math.max(0,window.scrollY+graph.getBoundingClientRect().top-(header?.getBoundingClientRect().height||60)-12),behavior:window.matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'});return;}
  if(d.liquid!=null){selectLiquid(Number(d.liquid));return;}
  if(d.mood){state.mood=d.mood;state.expandedId=null;renderMoodMoment();renderResults();return;}
  if(d.moment){state.moment=d.moment;state.expandedId=null;renderMoodMoment();renderResults();return;}
  if(d.expand){state.expandedId=state.expandedId===d.expand?"":d.expand;renderResults();}
 });
 if(!window.RTA_ATLAS_SEARCH_UI){
 element("liquidSearch").addEventListener("input",renderSuggestions);
 element("liquidSearch").addEventListener("keydown",ev=>{
  const list=element("liquidSuggestions"),input=ev.currentTarget;
  if(ev.key==="Escape"){
   closeSuggestions();
   return;
  }
  if(ev.key==="ArrowDown"||ev.key==="ArrowUp"){
   const options=[...list.querySelectorAll("[data-liquid]")];
   if(list.hidden||!options.length)return;
   ev.preventDefault();
   state.activeSuggestion=(state.activeSuggestion+(ev.key==="ArrowDown"?1:-1)+options.length)%options.length;
   options.forEach((option,i)=>{
    option.classList.toggle("is-active",i===state.activeSuggestion);
    option.setAttribute("aria-selected",String(i===state.activeSuggestion));
   });
   input.setAttribute("aria-activedescendant",options[state.activeSuggestion].id);
   options[state.activeSuggestion].scrollIntoView({block:"nearest"});
   return;
  }
  if(ev.key==="Enter"&&!list.hidden){
   const hits=liquidSearch(input.value,10);
   if(hits.length){ev.preventDefault();selectLiquid(hits[Math.min(state.activeSuggestion,hits.length-1)].index);}
  }
 });
 document.addEventListener("focusin",ev=>{
  if(!ev.target.closest?.(".liquid-search-wrap"))closeSuggestions();
 });
 document.addEventListener("click",ev=>{
  if(!ev.target.closest?.(".liquid-search-wrap"))closeSuggestions();
 });
 element("clearSearch").addEventListener("click",()=>{
  element("liquidSearch").value="";
  element("liquidSearch").focus();
  renderSuggestions();
 });
 }
 element("matchButton").addEventListener("click",()=>{
  state.expandedId=null;renderResults();
  scrollToBest();
 });
 element('atlasBack')?.addEventListener('click',()=>{if(navigationTrail.length){window.history.back();}else{route('home',false);window.history.replaceState(null,'','#home');}});
 window.addEventListener("popstate",()=>{const to=window.location.hash.slice(1)||'home';if(navigationTrail[navigationTrail.length-1]===to)navigationTrail.pop();else if(to!==state.route)navigationTrail.push(state.route);route(to,false);});
}
window.RTA_ATLAS_PREVIEW={
 version:"0.2-real-photo-motion",setFreeProfile,setObjective,setContext,compose,liquidSearch,buildString,compactBuild,
 currentLiquid,effectiveGoal,renderResults,drawScene,renderCoil,renderBuild,comparisonGraphic,renderProductPhoto:renderAbstractAtom,qualities,vapeDescription,evidenceFor,state,route,selectLiquid,getSourceModel:()=>({atoms:atoms.length,liquids:catalog.length}),
 init
};
if(typeof document!=="undefined")document.addEventListener("DOMContentLoaded",init);
})();
