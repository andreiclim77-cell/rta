window.RTA_WIRES=[
  {
    "id":"k128",
    "name":"K1 28 GA round",
    "wraps":"5",
    "diam":"Ø2,5 mm",
    "power":"12–13,5 W",
    "kind":"WATT",
    "role":"etalonul și alternativa watt: hit bun, corp curat, mouthfeel și redare completă",
    "traits":{"tobacco":4.8,"layers":4.0,"body":4.8,"th":4.6,"smooth":4.2,"bright":3.5,"dry":4.4,"dark":4.8,"sweet":3.7,"complete":4.7}
  },
  {
    "id":"k129",
    "name":"K1 29 GA round",
    "wraps":"5–6 după airflow",
    "diam":"Ø2,5 mm",
    "power":"11,5–13 W",
    "kind":"WATT",
    "role":"hit/TH, uscăciune, precizie, focus și tobacco-first",
    "traits":{"tobacco":5.0,"layers":3.5,"body":3.5,"th":5.0,"smooth":3.7,"bright":4.1,"dry":5.0,"dark":4.2,"sweet":2.7,"complete":4.3}
  },
  {
    "id":"k1clap",
    "name":"K1 Clapton 2×30+38",
    "wraps":"5",
    "diam":"Ø2,5 mm",
    "power":"11,5–13,5 W",
    "kind":"WATT",
    "role":"corp, densitate, mouthfeel, TH și integrarea notelor; Clapton cald și tobacco-rich",
    "traits":{"tobacco":4.7,"layers":4.4,"body":5.0,"th":4.9,"smooth":4.0,"bright":3.3,"dry":3.8,"dark":5.0,"sweet":4.3,"complete":4.8}
  },
  {
    "id":"ssclap",
    "name":"SS316L Clapton 2×30+38",
    "wraps":"5",
    "diam":"Ø2,5 mm",
    "power":"11–13 W",
    "kind":"WATT / TC SS",
    "role":"claritate, top-notes, layering și răspuns mai rapid decât K1 Clapton, cu corp de Clapton",
    "traits":{"tobacco":4.2,"layers":5.0,"body":4.6,"th":4.4,"smooth":4.6,"bright":5.0,"dry":3.4,"dark":4.0,"sweet":4.5,"complete":4.8}
  },
  {
    "id":"nife30",
    "name":"NiFe TC · NiFe30 / NiFe52",
    "wraps":"NiFe30 7 pe toate platformele compatibile · NiFe52 6",
    "diam":"Ø2,5 mm",
    "power":"TC 225–235°C · limită 12–15 W; RESISTHERM NiFe30 și WATT 12 W",
    "kind":"TC",
    "wattNiFe30":{"powerW":12,"chipsets":["Dicodes","YiHi","ARC1","DNA"],"observedWraps":7,"status":"opțiune personală WATT, căldură mai echilibrată decât la 13 W; nu reprezintă test pe toate modurile"},
    "role":"NiFe30 alternativ WATT la 12 W (Dicodes, YiHi, ARC1, DNA), fără modificarea NiFe52/6 în TC; finețe, consistență termică, layering și completitudine; Dicodes RESISTHERM NiFe30 TCR 320 = 7 spire ca alegere personală globală, cu 6 istorice încă funcționale, rolă 5,5 Ω/m; Zivipf NiFe52 TCR 310 = 6 spire pe toate platformele; pe 415 Cool, apoi K1 28 GA / 6 spire",
    "materialSpecs":{
      "dicodesResisthermNiFe30":{
        "name":"Dicodes RESISTHERM NiFe30",
        "tcr":320,
        "resistanceOhmPerM":5.5,
        "baselineWraps":7,
        "coilDiameterMm":2.5,
        "evidence":"identitate fir și 5,5 Ω/m confirmate pe etichetă 30.08.2026; alegerea de 7 spire pe toate atomizoarele declarată 29.10.2026; 6 spire rămân referință istorică",
        "status":"specificație material confirmată direct; geometrie actualizată prin preferință declarată (nu A/B pentru toate RTA)"
      },
      "zivipfNiFe52":{
        "name":"Zivipf NiFe52",
        "tcr":310,
        "baselineWraps":6,
        "coilDiameterMm":2.5
      }
    },
    "traits":{"tobacco":4.7,"layers":5.0,"body":4.4,"th":4.1,"smooth":5.0,"bright":4.6,"dry":4.0,"dark":4.6,"sweet":4.4,"complete":5.0}
  }
];